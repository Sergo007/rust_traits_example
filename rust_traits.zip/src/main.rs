#![allow(unused_variables, dead_code)]

use google_bigquery_storage::BigqueryStorage;
use postgres_stogage::PostgresStorage;

mod google_bigquery_storage;
mod postgres_stogage;

trait Storage {
    fn get_patient_mapping(&self, id: i32) -> String;
    fn get_facility_mapping(&self, _id: i32) -> String;
}

fn sync_patient<S: Storage>(storage: &S, patient_id: i32) -> String {
    storage.get_facility_mapping(patient_id);
    storage.get_patient_mapping(patient_id)
}

fn sync_alergy<S: Storage>(storage: &S, patient_id: i32) -> String {
    storage.get_facility_mapping(patient_id);
    storage.get_patient_mapping(patient_id)
}

fn main() {
    let postgresql = PostgresStorage {
        connection: "Postgres".to_string(),
    };
    let bigquey = BigqueryStorage {
        connection: "Postgres".to_string(),
    };
    sync_patient(&bigquey, 1);
    // `_a` *won't* be `drop`ed again here, because it already has been
    // (manually) `drop`ed
}
