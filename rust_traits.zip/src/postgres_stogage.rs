use crate::Storage;

pub struct PostgresStorage {
    pub connection: String,
}

impl Storage for PostgresStorage {
    fn get_patient_mapping(&self, id: i32) -> String {
        format!("get_patient_mapping PostgresStorage: {}", id)
    }
    fn get_facility_mapping(&self, id: i32) -> String {
        format!("get_facility_mapping PostgresStorage: {}", id)
    }
}
